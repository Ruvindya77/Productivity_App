package com.example.productivityapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity2 : AppCompatActivity() {

    // Declare variables at the class level to avoid scope issues
    private lateinit var taskTitle: EditText
    private lateinit var taskDescription: EditText
    private lateinit var taskDueDate: EditText
    private lateinit var taskCompleteCheckbox: CheckBox
    private lateinit var addTaskButton: Button
    private lateinit var readTaskButton: Button  // Match ID with XML layout
    private lateinit var updateTaskButton: Button
    private lateinit var taskListView: ListView
    private lateinit var btnNavigate: Button

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var adapter: ArrayAdapter<String>
    private var taskList: MutableList<String> = mutableListOf()
    private var selectedTaskIndex: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        // Initialize UI elements
        taskTitle = findViewById(R.id.etTaskTitle)
        taskDescription = findViewById(R.id.etTaskDescription)
        taskDueDate = findViewById(R.id.etTaskDate)
        taskCompleteCheckbox = findViewById(R.id.checkBoxComplete)
        addTaskButton = findViewById(R.id.btnAddTask)
        readTaskButton = findViewById(R.id.btnReadTasks) // Updated to match XML ID
        updateTaskButton = findViewById(R.id.btnUpdateTask)
        taskListView = findViewById(R.id.taskListView)
        btnNavigate = findViewById(R.id.btnStopwatch)

        sharedPreferences = this.getSharedPreferences("TaskPrefs", MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        // Set up the adapter for ListView
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, taskList)
        taskListView.adapter = adapter

        // Click listener for ListView items
        taskListView.setOnItemClickListener { _, _, position, _ ->
            val selectedTask = taskList[position]
            val taskParts = selectedTask.split("\nDescription: ")

            if (taskParts.size == 2) {
                val selectedTitle = taskParts[0].replace("Title: ", "")
                val descriptionAndRest = taskParts[1].split("\nDue Date: ")
                val selectedDescription = descriptionAndRest[0]
                val dueDateAndStatus = descriptionAndRest[1].split("\nStatus: ")
                val selectedDueDate = dueDateAndStatus[0]
                val taskStatus = dueDateAndStatus[1] == "Completed"

                taskCompleteCheckbox.isChecked = taskStatus
                showUpdateDeleteDialog(position, selectedTitle, selectedDescription, selectedDueDate, taskStatus, editor)
            }
        }

        // Add Task button click listener
        addTaskButton.setOnClickListener {
            val titleText = taskTitle.text.toString()
            val descriptionText = taskDescription.text.toString()
            val dueDateText = taskDueDate.text.toString()
            val isTaskComplete = taskCompleteCheckbox.isChecked

            if (titleText.isNotEmpty() && descriptionText.isNotEmpty() && dueDateText.isNotEmpty()) {
                val taskStatus = if (isTaskComplete) "Completed" else "Incomplete"
                val newTask = "Title: $titleText\nDescription: $descriptionText\nDue Date: $dueDateText\nStatus: $taskStatus"
                taskList.add(newTask)
                saveTasksToPreferences(editor)
                clearInputFields()
                Toast.makeText(this, "Task Added", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show()
            }
        }

        // Update Task button click listener
        updateTaskButton.setOnClickListener {
            val updateTitle = taskTitle.text.toString()
            val updateDescription = taskDescription.text.toString()
            val updateDueDate = taskDueDate.text.toString()
            val isTaskComplete = taskCompleteCheckbox.isChecked

            if (selectedTaskIndex != -1 && updateTitle.isNotEmpty() && updateDescription.isNotEmpty() && updateDueDate.isNotEmpty()) {
                val taskStatus = if (isTaskComplete) "Completed" else "Incomplete"
                val updatedTask = "Title: $updateTitle\nDescription: $updateDescription\nDue Date: $updateDueDate\nStatus: $taskStatus"
                taskList[selectedTaskIndex] = updatedTask
                saveTasksToPreferences(editor)
                adapter.notifyDataSetChanged()
                clearInputFields()
                Toast.makeText(this, "Task Updated", Toast.LENGTH_SHORT).show()
                selectedTaskIndex = -1
            } else {
                Toast.makeText(this, "Please select a task to update", Toast.LENGTH_SHORT).show()
            }
        }

        // Read Tasks button click listener
        readTaskButton.setOnClickListener {
            loadTasksFromPreferences()
        }

        // Navigate to another activity
        btnNavigate.setOnClickListener {
            val intent = Intent(this, MainActivity3::class.java)
            startActivity(intent)
        }
    }

    // Method to show update/delete dialog
    private fun showUpdateDeleteDialog(
        position: Int,
        title: String,
        description: String,
        dueDate: String,
        isComplete: Boolean,
        editor: SharedPreferences.Editor
    ) {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setTitle("Update or Delete Task")
        dialogBuilder.setMessage("What do you want to do with this task?")

        dialogBuilder.setPositiveButton("Update") { _, _ ->
            selectedTaskIndex = position
            taskTitle.setText(title)
            taskDescription.setText(description)
            taskDueDate.setText(dueDate)
            taskCompleteCheckbox.isChecked = isComplete
        }

        dialogBuilder.setNegativeButton("Delete") { _, _ ->
            taskList.removeAt(position)
            saveTasksToPreferences(editor)
            adapter.notifyDataSetChanged()
            Toast.makeText(this, "Task Deleted", Toast.LENGTH_SHORT).show()
        }

        val alertDialog = dialogBuilder.create()
        alertDialog.show()
    }

    // Method to save tasks to SharedPreferences
    private fun saveTasksToPreferences(editor: SharedPreferences.Editor) {
        val taskSet = taskList.toSet() // Convert taskList to Set for SharedPreferences storage
        editor.putStringSet("tasks", taskSet)
        editor.apply()
    }

    // Method to clear input fields
    private fun clearInputFields() {
        taskTitle.text.clear()
        taskDescription.text.clear()
        taskDueDate.text.clear()
        taskCompleteCheckbox.isChecked = false
    }

    // Method to load tasks from SharedPreferences
    private fun loadTasksFromPreferences() {
        val taskSet = sharedPreferences.getStringSet("tasks", setOf())
        if (taskSet != null) {
            taskList.clear()
            taskList.addAll(taskSet)
            adapter.notifyDataSetChanged()
            Toast.makeText(this, "Tasks Loaded", Toast.LENGTH_SHORT).show()
        }
    }
}
