package com.example.productivityapp

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity3 : AppCompatActivity() {

    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnReset: Button
    private lateinit var tvTimer: TextView
    private var isRunning = false
    private var startTime = 0L
    private val handler = Handler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnReset = findViewById(R.id.btnReset)
        tvTimer = findViewById(R.id.tvTimer)

        btnStart.setOnClickListener {
            if (!isRunning) {
                startStopwatch()
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SCHEDULE_EXACT_ALARM) == PackageManager.PERMISSION_GRANTED) {
                    scheduleReminder(10) // Set reminder for 10 seconds
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SCHEDULE_EXACT_ALARM), 1)
                }
            }
        }

        btnStop.setOnClickListener {
            stopStopwatch()
        }

        btnReset.setOnClickListener {
            resetStopwatch()
        }
    }

    private fun startStopwatch() {
        isRunning = true
        startTime = SystemClock.elapsedRealtime()

        // Update the timer display every second
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (isRunning) {
                    val elapsedMillis = SystemClock.elapsedRealtime() - startTime
                    val seconds = (elapsedMillis / 1000).toInt() % 60
                    val minutes = (elapsedMillis / (1000 * 60) % 60).toInt()
                    val hours = (elapsedMillis / (1000 * 60 * 60) % 24).toInt()
                    tvTimer.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                    handler.postDelayed(this, 1000)
                }
            }
        }, 0)
    }

    private fun stopStopwatch() {
        isRunning = false
        handler.removeCallbacksAndMessages(null) // Stop the handler
    }

    private fun resetStopwatch() {
        isRunning = false
        tvTimer.text = "00:00:00" // Reset timer display
        handler.removeCallbacksAndMessages(null) // Stop the handler
    }

    private fun scheduleReminder(seconds: Int) {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderBroadcastReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Set the alarm to go off after 'seconds' seconds
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + seconds * 1000, pendingIntent)
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        handler.removeCallbacksAndMessages(null) // Stop the handler when the activity is destroyed
    }
}
