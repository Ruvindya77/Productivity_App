package com.example.productivityapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.Manifest

class ReminderBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // Check if the app has notification permission
        if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            // Build and display the notification
            val builder = NotificationCompat.Builder(context, "reminderChannel")
                .setContentTitle("Reminder")
                .setContentText("Your 10 seconds reminder is up!")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true) // Auto-dismiss notification after clicking it

            // Get the NotificationManager and send the notification
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(1, builder.build()) // Notification ID 1
        } else {
            // Handle the case when permission is not granted
            // For instance, you can request permission here or display an error log
        }
    }
}
